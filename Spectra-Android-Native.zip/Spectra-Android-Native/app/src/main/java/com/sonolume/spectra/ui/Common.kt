package com.sonolume.spectra.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sonolume.spectra.daw.DawUiState
import com.sonolume.spectra.daw.DawViewModel

@Composable
fun DawViewModel.collectUi(): DawUiState {
    val v by ui.collectAsStateWithLifecycle()
    return v
}

@Composable
fun TrackHead(
    title: String,
    tag: String,
    folded: Boolean,
    onFold: () -> Unit,
    onOpenInstrument: () -> Unit,
    onClear: () -> Unit,
    fxOpen: Boolean,
    onFx: () -> Unit,
    mute: Boolean,
    solo: Boolean,
    onMute: () -> Unit,
    onSolo: () -> Unit,
    controls: @Composable RowScope.() -> Unit
) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            SmallBtn(if (folded) "▸" else "▾", onFold)
            Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = SpectraText)
            Text(tag, fontSize = 12.sp, color = SpectraMuted)
        }
        if (!folded) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                ToggleBtn("Mute", mute) { onMute() }
                ToggleBtn("Solo", solo) { onSolo() }
                controls()
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                ToggleBtn("FX", fxOpen) { onFx() }
                SmallBtn("Clear", onClear, warn = true)
                SmallBtn("Open instrument", onOpenInstrument)
            }
        }
    }
}

@Composable
fun SmallBtn(text: String, onClick: () -> Unit, warn: Boolean = false, on: Boolean = false) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(
            containerColor = when {
                on -> SpectraGreen
                warn -> Color(0xFF5A2323)
                else -> Color(0xFF2A3248)
            },
            contentColor = SpectraText
        )
    ) {
        Text(text, fontSize = 12.sp)
    }
}

@Composable
fun ToggleBtn(text: String, on: Boolean, onClick: () -> Unit) {
    SmallBtn(text, onClick, on = on)
}

@Composable
fun VolSlider(label: String, value: Float, onChange: (Float) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 12.sp, color = SpectraMuted)
        Slider(
            value = value,
            onValueChange = onChange,
            valueRange = 0f..1f,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
fun FxCheckRow(name: String, on: Boolean, onToggle: (Boolean) -> Unit, content: @Composable () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(end = 4.dp)) {
            Checkbox(checked = on, onCheckedChange = onToggle)
            Text(name, fontSize = 12.sp, color = SpectraText)
        }
        Column(Modifier.weight(1f, fill = false)) { content() }
    }
}

@Composable
fun FxSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 12.sp, color = SpectraMuted)
        Slider(
            value = value.coerceIn(range.start, range.endInclusive),
            onValueChange = onChange,
            valueRange = range,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
fun Hint(text: String) {
    Text(text, fontSize = 11.sp, color = SpectraMuted, modifier = Modifier.padding(8.dp))
}
