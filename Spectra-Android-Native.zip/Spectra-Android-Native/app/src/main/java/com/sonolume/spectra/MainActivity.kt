package com.sonolume.spectra

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.webkit.WebMessageCompat
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.max

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private var audioServiceStarted = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 9, 13)
        window.navigationBarColor = Color.rgb(8, 9, 13)

        webView = WebView(this).apply {
            setBackgroundColor(Color.rgb(8, 9, 13))
            overScrollMode = View.OVER_SCROLL_NEVER
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.cacheMode = WebSettings.LOAD_DEFAULT
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        }
        setContentView(webView)

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest) =
                loader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                if (u.host == "appassets.androidplatform.net") return false
                return true
            }
        }

        installNativeBridge()
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    private fun ensureAudioService() {
        if (!audioServiceStarted) {
            audioServiceStarted = true
            ContextCompat.startForegroundService(this, Intent(this, AudioService::class.java))
        }
        NativeAudio.start()
    }

    private fun installNativeBridge() {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
            throw IllegalStateException("This Android System WebView is too old for Spectra's native audio bridge.")
        }
        WebViewCompat.addWebMessageListener(
            webView,
            "SpectraNative",
            setOf("https://appassets.androidplatform.net"),
            object : WebViewCompat.WebMessageListener {
                override fun onPostMessage(
                    view: WebView,
                    message: WebMessageCompat,
                    sourceOrigin: Uri,
                    isMainFrame: Boolean,
                    replyProxy: androidx.webkit.JavaScriptReplyProxy
                ) {
                    if (!isMainFrame) return
                    val raw = message.data ?: return
                    try { handleNativeMessage(JSONObject(raw)) }
                    catch (_: Throwable) { }
                }
            }
        )
    }

    private fun f(o: JSONObject, k: String, d: Double = 0.0) = o.optDouble(k, d).toFloat()
    private fun floats(a: JSONArray?): FloatArray {
        if (a == null) return FloatArray(0)
        return FloatArray(a.length()) { i -> a.optDouble(i, 0.0).toFloat() }
    }
    private fun pointArray(a: JSONArray?, key: String): Pair<FloatArray, FloatArray> {
        if (a == null) return FloatArray(0) to FloatArray(0)
        val n = minOf(16, a.length())
        val t = FloatArray(n)
        val v = FloatArray(n)
        for (i in 0 until n) {
            val p = a.optJSONObject(i) ?: continue
            t[i] = p.optDouble("t", 0.0).toFloat().coerceIn(0f, 1f)
            v[i] = p.optDouble(key, 0.0).toFloat()
        }
        return t to v
    }

    private fun handleNativeMessage(o: JSONObject) {
        when (o.optString("type")) {
            "ensure" -> ensureAudioService()
            "master" -> { ensureAudioService(); NativeAudio.setMaster(f(o,"value",0.9)) }
            "track" -> {
                ensureAudioService()
                val id = when (o.optString("track")) { "neb" -> 0; "spec" -> 1; else -> 2 }
                NativeAudio.setTrack(id, f(o,"value",0.8))
            }
            "reverb" -> { ensureAudioService(); NativeAudio.setGlobalReverb(f(o,"value")) }
            "delayMix" -> { ensureAudioService(); NativeAudio.setGlobalDelayMix(f(o,"value")) }
            "delayTime" -> { ensureAudioService(); NativeAudio.setGlobalDelayTime(f(o,"value",0.32)) }
            "nebFx" -> {
                ensureAudioService(); val x=o.optJSONObject("fx")?:JSONObject()
                NativeAudio.setNebFx(
                    x.optBoolean("dlyOn"), f(x,"dlyAmt",.25), f(x,"dlyFb",.35), f(x,"dlyTime",.32),
                    x.optBoolean("dstOn"), f(x,"dstAmt",25.0), f(x,"dstIn",1.0), f(x,"dstOut",.85),
                    x.optBoolean("verbOn"), f(x,"verbAmt",.25), f(x,"verbDecay",2.5)
                )
            }
            "specFx" -> {
                ensureAudioService(); val x=o.optJSONObject("fx")?:JSONObject()
                NativeAudio.setSpecFx(
                    x.optBoolean("dlyOn"), f(x,"dlyAmt",.4), f(x,"dlyFb",.3), f(x,"dlyTime",.25),
                    x.optBoolean("verbOn"), f(x,"verbAmt",.3), f(x,"verbRoom",.5)
                )
            }
            "drumFx" -> {
                ensureAudioService(); val x=o.optJSONObject("fx")?:JSONObject()
                NativeAudio.setDrumFx(x.optBoolean("verbOn"), f(x,"verbAmt",.18))
            }
            "neb" -> {
                ensureAudioService()
                val (bt,bv)=pointArray(o.optJSONArray("bend"),"st")
                val (vt,vv)=pointArray(o.optJSONArray("vex"),"v")
                NativeAudio.nebNote(
                    o.optInt("midi",60), f(o,"vel",.95), f(o,"dur",.25), max(0f,f(o,"delay")),
                    o.optBoolean("pluck"), f(o,"decay",700.0), bt,bv,vt,vv
                )
            }
            "spec" -> {
                ensureAudioService()
                val wave=when(o.optString("wave")){"sine"->0;"triangle"->1;"sawtooth"->2;else->3}
                NativeAudio.specNote(o.optInt("midi",60),f(o,"vel",.95),f(o,"dur",.25),max(0f,f(o,"delay")),wave)
            }
            "drum" -> {
                ensureAudioService()
                val kind=when(o.optString("kind")){"k"->0;"s"->1;else->2}
                NativeAudio.drumHit(kind,f(o,"freq",110.0),f(o,"vel",1.0),f(o,"pos",.5),max(0f,f(o,"delay")))
            }
            "click" -> { ensureAudioService(); NativeAudio.click(o.optBoolean("high"), max(0f,f(o,"delay"))) }
        }
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }
}
