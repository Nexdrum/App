#pragma once
#include <array>
#include <atomic>
#include <cstdint>
#include <vector>

class DspCore {
public:
    DspCore();
    void prepare(double sampleRate);
    void reset();
    void render(float* outInterleaved, int32_t frames);

    void setMaster(float v);
    void setTrack(int track, float v);
    void setGlobalReverb(float v);
    void setGlobalDelayMix(float v);
    void setGlobalDelayTime(float v);

    void setNebFx(bool dlyOn,float dlyAmt,float dlyFb,float dlyTime,
                  bool dstOn,float dstAmt,float dstIn,float dstOut,
                  bool verbOn,float verbAmt,float verbDecay);
    void setSpecFx(bool dlyOn,float dlyAmt,float dlyFb,float dlyTime,
                   bool verbOn,float verbAmt,float verbRoom);
    void setDrumFx(bool verbOn,float verbAmt);

    void nebNote(int midi,float vel,float durSec,float delaySec,bool pluck,float decayMs,
                 const float* bendT,const float* bendV,int bendN,
                 const float* vexT,const float* vexV,int vexN);
    void specNote(int midi,float vel,float durSec,float delaySec,int wave);
    void drumHit(int kind,float freq,float vel,float pos,float delaySec);
    void click(bool high,float delaySec);

    int sampleRate() const { return static_cast<int>(mSampleRate); }

private:
    static constexpr int MAX_POINTS=16;
    static constexpr int EVENT_Q=2048;
    static constexpr int PENDING_MAX=512;
    static constexpr int NEB_VOICES=40;
    static constexpr int SPEC_VOICES=64;
    static constexpr int DRUM_VOICES=28;
    static constexpr int CLICK_VOICES=8;

    enum class EventType:uint8_t { Neb, Spec, Drum, Click };
    struct Event {
        EventType type{};
        uint64_t frame=0;
        int i0=0,i1=0;
        float a=0,b=0,c=0,d=0,e=0;
        uint8_t n1=0,n2=0;
        std::array<float,MAX_POINTS> t1{},v1{},t2{},v2{};
    };

    struct Queue {
        std::array<Event,EVENT_Q> q{};
        std::atomic<uint32_t> head{0},tail{0};
        bool push(const Event& e);
        bool pop(Event& e);
    };

    struct Rng {
        uint32_t s=0x12345678u;
        inline float next(){ s^=s<<13; s^=s>>17; s^=s<<5; return (float(s&0x00ffffff)/8388607.5f)-1.f; }
    };

    struct Biquad {
        float b0=1,b1=0,b2=0,a1=0,a2=0,z1=0,z2=0;
        void clear(){z1=z2=0;}
        float process(float x){ float y=b0*x+z1; z1=b1*x-a1*y+z2; z2=b2*x-a2*y; return y; }
        void lowpass(double sr,float f,float q);
        void bandpass(double sr,float f,float q);
        void peaking(double sr,float f,float q,float gainDb);
    };

    struct Delay {
        std::vector<float> buf;
        int write=0;
        void init(int n){buf.assign(n,0.f);write=0;}
        void clear(){std::fill(buf.begin(),buf.end(),0.f);write=0;}
        float tick(float x,int delaySamples,float fb);
    };

    struct Comb {
        std::vector<float> b; int p=0; float damp=0,store=0;
        void init(int n){b.assign(n,0.f);p=0;store=0;}
        void clear(){std::fill(b.begin(),b.end(),0.f);p=0;store=0;}
        float tick(float x,float feedback,float d);
    };
    struct Allpass {
        std::vector<float> b; int p=0;
        void init(int n){b.assign(n,0.f);p=0;}
        void clear(){std::fill(b.begin(),b.end(),0.f);p=0;}
        float tick(float x,float feedback);
    };
    struct Reverb {
        std::array<Comb,4> l{},r{}; std::array<Allpass,2> al{},ar{};
        void init(double sr);
        void clear();
        void tick(float in,float feedback,float damp,float& L,float& R);
    };

    struct NebVoice {
        bool active=false; uint64_t start=0; uint64_t age=0;
        float baseFreq=440,vel=.95f,dur=.3f,rel=.7f,mute=0,pressure=0,onset=.1f;
        bool pluck=false;
        float phase=0,noiseState=0;
        std::array<float,18> amps{};
        Biquad body{},smooth{},noiseBand{};
        uint8_t bn=0,vn=0; std::array<float,MAX_POINTS> bt{},bv{},vt{},vv{};
        float interp(const std::array<float,MAX_POINTS>& t,const std::array<float,MAX_POINTS>& v,int n,float x,float def) const;
        float sample(double sr,uint64_t frame,Rng& rng);
    };

    struct SpecVoice {
        bool active=false; uint64_t start=0,age=0; float freq=440,vel=.9f,dur=.3f,phase=0; int wave=3;
        float sample(double sr,uint64_t frame);
    };

    struct DrumVoice {
        bool active=false; uint64_t start=0,age=0; int kind=0; float freq=110,vel=1,pos=.5f;
        std::array<float,8> phase{}; std::array<float,8> jitter{};
        Biquad n1{},n2{},n3{}; Rng rng{};
        float life=1;
        float sample(double sr,uint64_t frame);
    };

    struct ClickVoice { bool active=false; uint64_t start=0,age=0; float phase=0,freq=1400; float sample(double sr,uint64_t frame); };

    double mSampleRate=48000.0;
    std::atomic<uint64_t> mFrame{0};
    Queue mQueue;
    std::array<Event,PENDING_MAX> mPending{}; int mPendingN=0;
    std::array<NebVoice,NEB_VOICES> mNeb{};
    std::array<SpecVoice,SPEC_VOICES> mSpec{};
    std::array<DrumVoice,DRUM_VOICES> mDrum{};
    std::array<ClickVoice,CLICK_VOICES> mClick{};
    Rng mRng{};

    std::atomic<float> master{.9f},nebVol{.8f},specVol{.8f},drumVol{.9f};
    std::atomic<float> globalVerb{.18f},globalDelayMix{0.f},globalDelayTime{.32f};
    std::atomic<float> nebDlyAmt{0},nebDlyFb{.35f},nebDlyTime{.32f},nebDstAmt{25},nebDstIn{1},nebDstOut{.85f},nebVerbAmt{.35f},nebVerbDecay{2.5f};
    std::atomic<bool> nebDlyOn{false},nebDstOn{false},nebVerbOn{false};
    std::atomic<float> specDlyAmt{0},specDlyFb{.3f},specDlyTime{.25f},specVerbAmt{.35f},specVerbRoom{.5f};
    std::atomic<bool> specDlyOn{false},specVerbOn{false};
    std::atomic<float> drumVerbAmt{.5f}; std::atomic<bool> drumVerbOn{false};

    Delay nebDelay,specDelay,globalDelayL,globalDelayR;
    Reverb nebRev,specRev,roomRev;

    void schedule(Event e,float delaySec);
    void activate(const Event& e);
    void drainForBlock(uint64_t blockEnd);
    NebVoice& allocNeb(); SpecVoice& allocSpec(); DrumVoice& allocDrum(int kind); ClickVoice& allocClick();
    static float clamp(float x,float a,float b){return x<a?a:(x>b?b:x);}
    static float midiFreq(int m);
    static float nebMuteMix(bool pluck,float vel);
};
