# Spectra Android — Native C++/Oboe build

This is the first **real Android-native audio build** of Spectra.

## Architecture

- The existing Spectra mobile interface is bundled locally inside the APK as HTML/CSS/JavaScript.
- Android `WebViewAssetLoader` serves it from the private `appassets.androidplatform.net` origin — no web server or internet is required.
- `WebViewCompat.addWebMessageListener` is the bridge from the Spectra interface to Android.
- All DAW note events go to a native C++ DSP core.
- Oboe provides the Android low-latency output stream.
- The native engine uses fixed/reusable voice pools; it does not create Web Audio nodes per note.
- A foreground media-playback service keeps the native audio engine alive when Spectra is backgrounded.

## What is native in this build

The DAW sequencer's three tracks are rendered by C++:

- **Nebular** — harmonic string voice, bow/pluck envelopes, velocity-to-palm blend, pitch-bend line, velocity line, body filtering, bow/pluck noise.
- **Spectrachord** — native sine/triangle/saw/square oscillators with scheduled note lengths.
- **Nexdrum** — native procedural kick, snare and cymbal voices with continuous strike-position mapping.
- Master/track volume, track delay/distortion/reverb controls and global delay/reverb are handled natively.

The full instrument pages opened inside Spectra are still the existing embedded HTML instruments. The DAW itself does not use Web Audio in this Android build.

## Important first-build limitation

**Native WAV recording is not wired yet.** The existing record button is retained but currently reports that native recording is not enabled.

The C++ port preserves the behavior and control structure of the supplied `audio.js`, but it is **not bit-for-bit identical to Web Audio's built-in BiquadFilter/Convolver implementation**. This build is the native architecture baseline for listening/performance testing and subsequent sound matching.

## Build an APK with GitHub Actions

1. Create a new GitHub repository (for example `Spectra-Android`).
2. Put the contents of this folder at the root of the repository.
3. Push to the `main` branch.
4. Open **Actions → Build Spectra APK**.
5. Run the workflow if it did not start automatically.
6. When it finishes, open the build and download the **Spectra-Android-debug** artifact.
7. Extract the artifact ZIP and install `app-debug.apk` on Android.

Android may ask you to allow installation from the browser/file manager you use to open the APK.

## Android Studio

If you later use Android Studio, open this folder as the project. It targets:

- compile / target SDK 35
- min SDK 26
- NDK 27.2.12479018
- CMake 3.22.1
- Oboe 1.10.0

## Important source files

- `app/src/main/assets/index.html` — Spectra UI with the native audio shim instead of Web Audio.
- `app/src/main/java/com/sonolume/spectra/MainActivity.kt` — local WebView and JS/native bridge.
- `app/src/main/java/com/sonolume/spectra/AudioService.kt` — foreground native-audio lifetime.
- `app/src/main/cpp/DspCore.cpp` — Sonolume DSP core.
- `app/src/main/cpp/AudioEngine.cpp` — Oboe stream.
- `.github/workflows/build-apk.yml` — automatic APK build.

## Why this is different from the browser version

The browser build asks Web Audio to create and manage large graphs of oscillators, filters, gains, noise sources and convolution nodes. This build presents Oboe with one stereo callback. The C++ engine owns all voices and processes them directly into that buffer.
